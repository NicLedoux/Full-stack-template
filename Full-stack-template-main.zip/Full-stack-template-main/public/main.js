//This is where you put the code that reaches out to the server to send information back and forth.
//Info can travel back and forth using using fetches.